# ThisIsNotRat
[![HitCount](https://hits.dwyl.com/realb3y/RealBey/ThisIsNotRat.svg?style=flat-square)](http://hits.dwyl.com/realb3y/RealBey/ThisIsNotRat)


<p align="center">
👀Control your windows computeur from telegram 👀


<a href="https://ibb.co/SRWX61h"><img src="https://i.ibb.co/J50Rcbf/ideogram-15.jpg" alt="ideogram-15" border="0"></a>



⚙️INSTALLATION⚙️

pip install -r requirements.txt

🤖GET BOT API AND PASTE IN tinar.py🤖

![image](https://github.com/RealBey/ThisIsNotRat/assets/85953451/e05a6070-e841-45c1-9592-045263ac4499)


🏃🏼RUN🏃🏼

python tinar.py 



📣Commands📣

/screen to capture screenshot.🖵

/sys to get system informations.ℹ️

/ip to get ip adress.📟

/cd to navigate in folders.🗂️

/ls for list élements.🗂️

/upload [path] to get file.📤

/crypt [path] for crypt folders files. 🔒

/decrypt [path] for decrypt files.🔓

/webcam to get webcam capture.📷

/lock for lock the session.🔑

/clipoard to get clipboard.📋

/shell for pro.🖬

/wifi to get wifi password.📶

/speech [hi]  to speech tts.💬

/shutdown  🙅


DEMO:




https://github.com/RealBey/ThisIsNotRat/assets/85953451/72259af5-b9ea-4c1e-8ae4-3bcc58eca116







